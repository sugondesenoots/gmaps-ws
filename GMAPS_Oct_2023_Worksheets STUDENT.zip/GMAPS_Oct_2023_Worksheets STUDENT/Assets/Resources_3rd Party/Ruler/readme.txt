Ruler Tool

How to use:

1 Drag the horizontalRuler or verticalRuler to scene.
2 Change range of rulers just by scaling them.

Known issues:
Scene will always be unsaved state after run,because ruler need recreate mesh in "Start" function,to avoid shared mesh with duplicate.

Author:
orange030@gmail.com
http://en.zonozone.com/